<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Home::index');

/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
$routes->get('iniciar', 'Users::iniciarSesion');

$routes->get('cargartipouser', 'Tipousers::cargarTipo');
$routes->get('eliminartipos/(:num)', 'Tipousers::eliminarTipo/$1');
$routes->get('verformularioinsert', 'Tipousers::cargarformularioTipo');
$routes->get('aguardartipouser', 'Tipousers::guardarnuevoTipo');
$routes->get('verformulariouptadetipo/(:num)', 'Tipousers::modificarTipo/$1');
$routes->get('agaudarupdatetipos', 'Tipousers::aguargarmodificadoTipo');

$routes->get('cargaruser', 'Users::cargarUser');
$routes->get('eliminarusuario/(:num)', 'Users::eliminarUsuario/$1');
$routes->get('verformulariouser', 'Users::verformularioUsuarios');
$routes->get('aguardarusuario', 'Users::guardarUsuario');
$routes->get('verformularioupdateusuario/(:num)', 'Users::frmModificarUsuarios/$1');
$routes->get('aguardarupdateusuario', 'Users::modificarUsuarios');

$routes->get('cargardepto', 'Departamentos::cargarDepartamentos');
$routes->get('eliminardepto/(:num)', 'Departamentos::eliminarDepto/$1');
$routes->get('verformulariodepto', 'Departamentos::cargarformularDepto');
$routes->get('aguardardepto', 'Departamentos::guardarnuevoDepto');
$routes->get('verformularioudatedepto/(:num)', 'Departamentos::modificarDepto/$1');
$routes->get('aguardarusdatedepto', 'Departamentos::aguargarmodificadoDepto');

$routes->get('cargarmunicipio', 'Municipios::cargarMunicipio');
$routes->get('eliminarmuni/(:num)', 'Municipios::eliminarMunicipio/$1');
$routes->get('verformulariomuni', 'Municipios::cargarformularMunicipio');
$routes->get('aguardarinsertmuni', 'Municipios::guardarnuevoMunicipio');
$routes->get('verformularioupdatemuni/(:num)', 'Municipios::modificarMunicipio/$1');
$routes->get('aguardarupdatemuni', 'Municipios::aguargarmodificadoMunicipio');


$routes->get('cargaregion', 'Regiones::cargarRegion');
$routes->get('eliminarregion/(:num)', 'Regiones::eliminarRegion/$1');
$routes->get('verformularioinsertregion', 'Regiones::cargarformularRegion');
$routes->get('aguardarregion', 'Regiones::guardarnuevoRegion');
$routes->get('verformularioupdateregion/(:num)', 'Regiones::modificarRegion/$1');
$routes->get('aguardarupdateregion', 'Regiones::aguargarmodificadoRegion');

$routes->get('cargarNivel', 'NivelAcademicos::cargarNivel');
$routes->get('eliminarnivel/(:num)', 'NivelAcademicos::eliminarNivel/$1');
$routes->get('verformularioinsertnivel', 'NivelAcademicos::cargarformularNivel');
$routes->get('aguardarnivel', 'NivelAcademicos::guardarnuevoNivel');
$routes->get('verformularioupdatenivel/(:num)', 'NivelAcademicos::modificarNivel/$1');
$routes->get('aguardarupdetanivel', 'NivelAcademicos::aguargarmodificadoNivel');

$routes->get('cargarciudadano', 'Ciudadanos::cargarCiudadanos');
$routes->get('eliminarciudadanos/(:num)', 'Ciudadanos::eliminarCiudadanos/$1');
$routes->get('verformularioinsertciudadano', 'Ciudadanos::cargarformulaCiudadanos');
$routes->get('aguardarciudadanos', 'Ciudadanos::guardarnuevoCiudadanos');
$routes->get('verformularioupdateciudadanos/(:num)', 'Ciudadanos::modificaCiudadanos/$1');
$routes->get('aguardarupdateciudadano', 'Ciudadanos::aguargarmodificadoCiudadanos');
$routes->get('iniciosesionciudadanos', 'Ciudadanos::inicio');
$routes->get('vervistaciudadanos/(:num)', 'Ciudadanos::vervistaciudadanos/$1');

$routes->get('cargar_ciudadano', 'Gentes::cargarCiudadano');

<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Municipio;
class Municipios extends Controller{
    public function cargarMunicipio(){
        $municipios = new Municipio();
        
        $datos['municipio'] = $municipios-> orderBy('cod_muni' , 'ASC')->findAll();
            return view('encargado/muni',$datos);
    }

    public function eliminarMunicipio($codigo=null){
        $municipios = new Municipio();
        $municipios->delete($codigo);
       
        $datos['municipio']=$municipios->orderBy('cod_muni','ASC')->findAll();
        return view('encargado/muni',$datos);
    }

    public function cargarformularMunicipio(){
        return view('encargado/insertmuni');
    }
    public function guardarnuevoMunicipio(){
        $municipios = new Municipio();

        $txttipo=$this->request->getVar('txttipousuario');
        $txtnombre=$this->request->getVar('txtnombre');
        $txtdes=$this->request->getVar('txtdes');

        $datos=[
            'cod_muni'=>$txttipo,
            'nombre'=>$txtnombre,
            'cod_depto'=>$txtdes
        ];
        $municipios->insert($datos);

        $datos['municipio']=$municipios->orderBy('cod_muni','ASC')->findAll();
        return view('encargado/muni',$datos);
    }

    public function modificarMunicipio($codigo=null){
        $municipios = new Municipio();

        $datos['muni']=$municipios->where('cod_muni',$codigo)->first();
        return view('encargado/updatemuni',$datos);
    }
    public function aguargarmodificadoMunicipio(){
        $municipios = new Municipio();

        $txttipo=$this->request->getVar('txttipousuario');
        $txtnombre=$this->request->getVar('txtnombre');
        $txtdes=$this->request->getVar('txtdes');

        $datos=[
            'cod_muni'=>$txttipo,
            'nombre'=>$txtnombre,
            'cod_depto'=>$txtdes
        ];
        $municipios->update($txttipo,$datos);

        
        $datos['municipio']=$municipios->orderBy('cod_muni','ASC')->findAll();
        return view('encargado/muni',$datos);
    }
}
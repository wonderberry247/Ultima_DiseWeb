<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Departamento;
class Departamentos extends Controller{
    public function cargarDepartamentos(){
        $departamentos = new Departamento();
        
        $datos['depto'] = $departamentos-> orderBy('cod_depto' , 'ASC')->findAll();
            return view('encargado/depto',$datos);
    }

    public function eliminarDepto($codigo=null){
        $departamentos = new Departamento();
        $departamentos->delete($codigo);
       
        $datos['depto']=$departamentos->orderBy('cod_depto','ASC')->findAll();
        return view('encargado/depto',$datos);
    }

    public function cargarformularDepto(){
        return view('encargado/insertdepto');
    }
    public function guardarnuevoDepto(){
        $departamentos = new Departamento();

        $txttipo=$this->request->getVar('txttipousuario');
        $txtnombre=$this->request->getVar('txtnombre');
        $txtdes=$this->request->getVar('txtdes');

        $datos=[
            'cod_depto'=>$txttipo,
            'nombre'=>$txtnombre,
            'cod_region'=>$txtdes
        ];
        $departamentos->insert($datos);

        $datos['depto']=$departamentos->orderBy('cod_depto','ASC')->findAll();
        return view('encargado/depto',$datos);
    }

    public function modificarDepto($codigo=null){
        $departamentos = new Departamento();

        $datos['depto']=$departamentos->where('cod_depto',$codigo)->first();
        return view('encargado/updatedepto',$datos);
    }
    public function aguargarmodificadoDepto(){
        $departamentos = new Departamento();

        $txttipo=$this->request->getVar('txttipousuario');
        $txtnombre=$this->request->getVar('txtnombre');
        $txtdes=$this->request->getVar('txtdes');

        $datos=[
            'cod_depto'=>$txttipo,
            'nombre'=>$txtnombre,
            'cod_region'=>$txtdes
        ];
        $departamentos->update($txttipo,$datos);

        
        $datos['depto']=$departamentos->orderBy('cod_depto','ASC')->findAll();
        return view('encargado/depto',$datos); 
    }

}
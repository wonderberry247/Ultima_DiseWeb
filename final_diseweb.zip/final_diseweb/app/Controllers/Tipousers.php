<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Tipouser;
class Tipousers extends Controller{
    public function cargarTipo(){
        $tipo = new Tipouser();
        
        $datos['tipos'] = $tipo-> orderBy('tipousuario_id' , 'ASC')->findAll();
            return view('admi/tiposuser',$datos);
    }

    public function eliminarTipo($codigo=null){
        $tipo = new Tipouser();
        $tipo->delete($codigo);
       
        $datos['tipos']=$tipo->orderBy('tipousuario_id','ASC')->findAll();
        return view('admi/tiposuser',$datos);
    }

    public function cargarformularioTipo(){
        return view('admi/inserttipouser');
    }
    public function guardarnuevoTipo(){
        $tipo = new Tipouser();

        $txttipo =$this->request->getVar('txttipousuario');
        $txtnombre =$this->request->getVar('txtnombre');

        $datos=[
            'tipousuario_id'=>$txttipo,
            'nombre'=>$txtnombre
        ];
        $tipo->insert($datos);

        $datos['tipos']=$tipo->orderBy('tipousuario_id','ASC')->findAll();
        return view('admi/tiposuser',$datos);
    }

    public function modificarTipo($codigo=null){
        $tipo = new Tipouser();

        $datos['tipos']=$tipo->where('tipousuario_id',$codigo)->first();
        return view('admi/updatetipouser',$datos);
    }
    public function aguargarmodificadoTipo(){

        $tipo = new Tipouser();

        $txttipo =$this->request->getVar('txttipousuario');
        $txtnombre =$this->request->getVar('txtnombre');

        $datos=[
            'nombre'=>$txtnombre
        ];
        $tipo->update($txttipo,$datos);

        
        $datos['tipos']=$tipo->orderBy('tipousuario_id','ASC')->findAll();
        return view('admi/tiposuser',$datos); 
    }

}
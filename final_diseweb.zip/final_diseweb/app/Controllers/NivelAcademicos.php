<?php 
namespace App\Controllers;

use App\Models\NivelAcademico;
use CodeIgniter\Controller;

class NivelAcademicos extends Controller{
    public function cargarNivel(){
        $niveles = new NivelAcademico();
        
        $datos['nivel'] = $niveles-> orderBy('cod_nivel_acad' , 'ASC')->findAll();
            return view('encargado/nevelacad',$datos);
    }

    public function eliminarNivel($codigo=null){
        $niveles = new NivelAcademico();
        $niveles->delete($codigo);
       
        $datos['nivel']=$niveles->orderBy('cod_nivel_acad','ASC')->findAll();
        return view('encargado/nevelacad',$datos);
    }

    public function cargarformularNivel(){
        return view('encargado/insertnevelacad');
    }
    public function guardarnuevoNivel(){
        $niveles = new NivelAcademico();

        $txttipo=$this->request->getVar('txttipousuario');
        $txtnombre=$this->request->getVar('txtnombre');
        $txtdes=$this->request->getVar('txtdes');

        $datos=[
            'cod_nivel_acad'=>$txttipo,
            'nombre'=>$txtnombre,
            'descripcion'=>$txtdes
        ];
        $niveles->insert($datos);

        $datos['nivel']=$niveles->orderBy('cod_nivel_acad','ASC')->findAll();
        return view('encargado/nevelacad',$datos);
    }

    public function modificarNivel($codigo=null){
        $niveles = new NivelAcademico();

        $datos['nivel']=$niveles->where('cod_nivel_acad',$codigo)->first();
        return view('encargado/updatenevelacad',$datos);
    }
    public function aguargarmodificadoNivel(){
        $niveles = new NivelAcademico();

        $txttipo=$this->request->getVar('txttipousuario');
        $txtnombre=$this->request->getVar('txtnombre');
        $txtdes=$this->request->getVar('txtdes');

        $datos=[
            'cod_nivel_acad'=>$txttipo,
            'nombre'=>$txtnombre,
            'descripcion'=>$txtdes
        ];
        $niveles->update($txttipo,$datos);

        
        $datos['nivel']=$niveles->orderBy('cod_nivel_acad','ASC')->findAll();
        return view('encargado/nevelacad',$datos);
    }
}
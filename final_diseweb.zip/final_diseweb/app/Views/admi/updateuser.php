<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar</title>
</head>
<body>
    <form class="login-from" action="<?=base_url('aguardarupdateusuario')?>" method="get">
        <h1>Actualizar</h1>
        <div class="input-group span-2">
        <label for="txttipousuario">Dpi:</label>
                <input type="text" name="txttipousuario" value="<?=$user['dpi']?>" readonly>
        </div>
        <div class="input-group span-2">
        <label for="txtnombre">Usuarios:</label>
                <input type="text" name="txtnombre" value="<?=$user['usuario']?>">
        </div>
        <div class="input-group span-2">
        <label for="txtpass">Contraseña:</label>
                <input type="text" name="txtpass" value="<?=$user['contra']?>">
        </div>
        <div class="input-group span-2">
        <label for="txttipo">Tipo Usuario:</label>
                <input type="text" name="txttipo" value="<?=$user['tipousuario_id']?>">
        </div>
        <div class="input-group span-2">
            <input type="submit" name="btnEnviar" value="Guardar datos">
        </div>
    </form>
</body>
</html>
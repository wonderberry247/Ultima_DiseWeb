<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar</title>
</head>
<body>
<form class="login-from" action="<?=base_url('aguardarupdateciudadano')?>" method="get">
        <h1>Actualizar </h1>
        <div class="input-group span-2">
        <label for="txtdpi">DPI:</label>
                <input type="text" name="txtdpi" value="<?=$ciudadano['dpi']?>" readonly>
        </div>
        <div class="input-group span-2">
        <label for="txtapellido">Apellido:</label>
                <input type="text" name="txtapellido" value="<?=$ciudadano['apellido']?>">
        </div>
        <div class="input-group span-2">
        <label for="txtnombre">Nombre:</label>
                <input type="text" name="txtnombre" value="<?=$ciudadano['nombre']?>">
        </div>
        <div class="input-group span-2">
        <label for="txtdireccion">Dirección:</label>
                <input type="text" name="txtdireccion" value="<?=$ciudadano['direccion']?>">
        </div>
        <div class="input-group span-2">
        <label for="txttelcasa">Telefono Casa:</label>
                <input type="text" name="txttelcasa" value="<?=$ciudadano['tel_casa']?>">
        </div>
        <div class="input-group span-2">
        <label for="txttelmovil">Telefono movil:</label>
                <input type="text" name="txttelmovil" value="<?=$ciudadano['tel_movil']?>">
        </div>
        <div class="input-group span-2">
        <label for="txtemail">Email:</label>
                <input type="text" name="txtemail" value="<?=$ciudadano['email']?>">
        </div>
        <div class="input-group span-2">
        <label for="txtfechanac">Fecha Nacimiento:</label>
                <input type="text" name="txtfechanac" value="<?=$ciudadano['fechanac']?>">
        </div>
        <div class="input-group span-2">
        <label for="txtcod_nivel">Codigo Nivel:</label>
                <input type="text" name="txtcod_nivel" value="<?=$ciudadano['cod_nivel_acad']?>">
        </div>
        <div class="input-group span-2">
        <label for="txtnacimiento">Lugar de nacimiento:</label>
                <input type="text" name="txtnacimiento" value="<?=$ciudadano['lugar_nacimiento']?>">
        </div>
        <div class="input-group span-2">
        <input type="submit" name="btnEnviar" value="Guardar datos">
        </div>
    </form>
</body>
</html>
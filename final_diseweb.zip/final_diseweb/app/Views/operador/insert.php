<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar</title>
</head>
<body>
    
    <form class="login-from" action="<?=base_url('aguardarciudadanos')?>" method="get">
        <h1>Agregar Ciudadanos</h1>
        <div class="input-group span-2">
        <label for="txtdpi">DPI:</label>
                <input type="text" name="txtdpi" placeholder="DPI">
        </div>
        <div class="input-group span-2">
        <label for="txtapellido">Apellido:</label>
                <input type="text" name="txtapellido" placeholder="Apellido">
        </div>
        <div class="input-group span-2">
        <label for="txtnombre">Nombre:</label>
                <input type="text" name="txtnombre" placeholder="Nombre">
        </div>
        <div class="input-group span-2">
        <label for="txtdireccion">Dirección:</label>
                <input type="text" name="txtdireccion" placeholder="Dirección">
        </div>
        <div class="input-group span-2">
        <label for="txttelcasa">Telefono Casa:</label>
                <input type="text" name="txttelcasa" placeholder="Telefono Casa">
        </div>
        <div class="input-group span-2">
        <label for="txttelmovil">Telefono movil:</label>
                <input type="text" name="txttelmovil" placeholder="Telefono movil">
        </div>
        <div class="input-group span-2">
        <label for="txtemail">Email:</label>
                <input type="text" name="txtemail" placeholder="Email">
        </div>
        <div class="input-group span-2">
        <label for="txtfechanac">Fecha Nacimiento:</label>
                <input type="text" name="txtfechanac" placeholder="Fecha nacimiento">
        </div>
        <div class="input-group span-2">
        <label for="txtcod_nivel">Codigo Nivel:</label>
                <input type="text" name="txtcod_nivel" placeholder="Código nivel">
        </div>
        <div class="input-group span-2">
        <label for="txtnacimiento">Lugar de nacimiento:</label>
                <input type="text" name="txtnacimiento" placeholder="Lugar de nacimiento">
        </div>
        <div class="input-group span-2">
        <input type="submit" name="btnEnviar" value="Guardar datos">
        </div>
    </form>

</body>
</html>
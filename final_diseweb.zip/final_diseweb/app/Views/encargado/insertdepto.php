<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar</title>
</head>
<body>
    
    <form class="login-from" action="<?=base_url('aguardardepto')?>" method="get">
        <h1>Agregar</h1>
        <div class="input-group span-2">
        <label for="txttipousuario">Código Departamento:</label>
                <input type="text" name="txttipousuario" placeholder="Ingrese Cod_Departamento">
        </div>
        <div class="input-group span-2">
        <label for="txtnombre">Nombre:</label>
                <input type="text" name="txtnombre" placeholder="Ingrese Nombre">
        </div>
        <div class="input-group span-2">
        <label for="txtdes">Cógigo Region:</label>
                <input type="text" name="txtdes" placeholder="Cógido Region">
        </div>
        <div class="input-group span-2">
            <input type="submit" name="btnEnviar" value="Guardar datos">
        </div>
    </form>

</body>
</html>